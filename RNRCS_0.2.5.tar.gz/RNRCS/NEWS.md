RNRCS v0.2.5 (Release date: 2018-03-21)
==============

Changes:

* Enables download of soil data, including soil moisture and temperature.
* FIxed a bug affecting solar radiation measurements.
